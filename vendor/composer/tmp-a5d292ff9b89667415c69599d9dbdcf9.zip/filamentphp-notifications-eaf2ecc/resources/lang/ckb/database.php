<?php

return [

    'modal' => [

        'heading' => 'ئاگانامەکان',

        'actions' => [

            'clear' => [
                'label' => 'سرینەوەی هەموو',
            ],

            'mark_all_as_read' => [
                'label' => 'نیشانە کردنی هەموو بۆ خوێنراوە',
            ],

        ],

        'empty' => [
            'heading' => 'هیچ ئاگانامەیەک نییە',
            'description' => 'تکایە دواتر سەردان بکە',
        ],

    ],

];
