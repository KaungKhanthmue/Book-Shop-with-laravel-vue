<?php

return [

    'modal' => [

        'heading' => 'Benachrichtigungen',

        'actions' => [

            'clear' => [
                'label' => 'Alle löschen',
            ],

            'mark_all_as_read' => [
                'label' => 'Alle als gelesen markieren',
            ],

        ],

        'empty' => [
            'heading' => 'Keine Benachrichtigungen vorhanden',
            'description' => 'Bitte schauen Sie später erneut vorbei',
        ],

    ],

];
