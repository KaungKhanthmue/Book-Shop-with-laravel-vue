<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'အညွန်း',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
