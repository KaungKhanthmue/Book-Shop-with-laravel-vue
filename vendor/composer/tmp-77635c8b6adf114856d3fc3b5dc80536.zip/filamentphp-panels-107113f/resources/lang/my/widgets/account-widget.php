<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'ထွက်မည်',
        ],

    ],

    'welcome' => 'ကြိုဆိုပါတယ်',

];
