<?php

return [

    'title' => 'Dashbord',

];
