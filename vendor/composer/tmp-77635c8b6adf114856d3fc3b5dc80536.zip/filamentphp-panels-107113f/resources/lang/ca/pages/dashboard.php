<?php

return [

    'title' => 'Escriptori',

];
