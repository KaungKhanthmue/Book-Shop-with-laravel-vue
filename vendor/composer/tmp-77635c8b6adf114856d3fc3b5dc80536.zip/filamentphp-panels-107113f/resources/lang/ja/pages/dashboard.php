<?php

return [

    'title' => 'ダッシュボード',

    'actions' => [

        'filter' => [

            'label' => 'フィルター',

            'modal' => [

                'heading' => 'フィルター',

                'actions' => [

                    'apply' => [

                        'label' => '適用',

                    ],

                ],

            ],

        ],

    ],

];
