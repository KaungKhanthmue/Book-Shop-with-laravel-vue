<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Odjava',
        ],

    ],

    'welcome' => 'Zdravo',

];
