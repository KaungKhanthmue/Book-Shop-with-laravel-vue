<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Változtatások mentése',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Mentve',
        ],

    ],

];
