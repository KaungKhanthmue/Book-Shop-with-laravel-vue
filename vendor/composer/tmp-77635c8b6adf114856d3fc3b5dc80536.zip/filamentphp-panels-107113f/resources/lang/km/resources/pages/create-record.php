<?php

return [

    'title' => 'បង្កើត :label',

    'breadcrumb' => 'បង្កើត',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'ចាកចេញ',
            ],

            'create' => [
                'label' => 'បង្កើត',
            ],

            'create_another' => [
                'label' => 'បង្កើត & បង្កើតឡើងវិញ',
            ],

        ],

    ],

    'notifications' => [

        'created' => [
            'title' => 'បានបង្កើត :label បានជោគជ័យ',
        ],

    ],

];
