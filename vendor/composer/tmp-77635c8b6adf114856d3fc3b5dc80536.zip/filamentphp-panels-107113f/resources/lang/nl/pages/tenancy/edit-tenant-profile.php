<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Wijzigingen opslaan',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Opgeslagen',
        ],

    ],

];
