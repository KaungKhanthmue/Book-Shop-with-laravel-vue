<?php

return [

    'title' => 'Dashboard',

    'actions' => [

        'filter' => [

            'label' => 'Filteren',

            'modal' => [

                'heading' => 'Filteren',

                'actions' => [

                    'apply' => [

                        'label' => 'Toepassen',

                    ],

                ],

            ],

        ],

    ],

];
