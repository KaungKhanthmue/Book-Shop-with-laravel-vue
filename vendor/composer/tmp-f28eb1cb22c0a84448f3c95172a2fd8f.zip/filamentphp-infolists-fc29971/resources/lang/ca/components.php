<?php

return [

    'text_entry' => [
        'more_list_items' => 'i :count més',
    ],

];
