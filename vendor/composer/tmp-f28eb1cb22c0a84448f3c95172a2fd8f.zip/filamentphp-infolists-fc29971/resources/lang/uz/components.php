<?php

return [

    'text_entry' => [
        'more_list_items' => 'va :count marta ko\'proq',
    ],

];
