<?php

return [

    'text_entry' => [
        'more_list_items' => 'និង :count ច្រើនទៀត',
    ],

];
