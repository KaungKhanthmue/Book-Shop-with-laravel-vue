<?php

return [

    'text_entry' => [
        'more_list_items' => ':count 항목이 더 있습니다',
    ],

];
