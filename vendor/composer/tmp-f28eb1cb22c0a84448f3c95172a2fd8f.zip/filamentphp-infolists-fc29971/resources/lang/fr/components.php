<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Afficher :count de moins',
                'expand_list' => 'Afficher :count de plus',
            ],

            'more_list_items' => 'et :count de plus',

        ],

    ],

];
