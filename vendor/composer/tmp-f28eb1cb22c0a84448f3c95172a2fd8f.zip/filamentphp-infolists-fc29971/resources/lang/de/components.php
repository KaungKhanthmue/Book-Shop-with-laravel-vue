<?php

return [

    'text_entry' => [
        'more_list_items' => 'und :count weitere',
    ],

];
