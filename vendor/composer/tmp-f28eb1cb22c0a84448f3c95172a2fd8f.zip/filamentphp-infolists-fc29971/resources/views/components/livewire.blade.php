<div>
    @livewire($getComponent(), $getComponentProperties())
</div>
