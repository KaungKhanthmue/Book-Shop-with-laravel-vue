<?php

namespace Filament\Support\Exceptions;

use Exception;

class Halt extends Exception
{
}
