<?php

return [

    'actions' => [

        'close' => [
            'label' => 'إغلاق',
        ],

    ],

];
