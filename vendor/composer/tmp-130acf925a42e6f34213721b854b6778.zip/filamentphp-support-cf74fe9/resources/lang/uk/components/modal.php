<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Закрити',
        ],

    ],

];
