<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Sluiten',
        ],

    ],

];
