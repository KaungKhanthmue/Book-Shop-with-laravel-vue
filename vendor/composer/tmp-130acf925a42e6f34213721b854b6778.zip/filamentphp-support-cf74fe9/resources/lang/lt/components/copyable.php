<?php

return [

    'messages' => [
        'copied' => 'Nukopijuota',
    ],

];
