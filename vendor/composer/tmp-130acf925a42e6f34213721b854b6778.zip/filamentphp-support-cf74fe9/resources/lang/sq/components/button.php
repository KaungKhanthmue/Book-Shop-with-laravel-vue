<?php

return [

    'messages' => [
        'uploading_file' => 'Duke ngarkuar skedarin...',
    ],

];
