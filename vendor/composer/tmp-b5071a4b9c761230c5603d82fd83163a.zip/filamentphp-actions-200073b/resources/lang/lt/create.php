<?php

return [

    'single' => [

        'label' => 'Sukurti :label',

        'modal' => [

            'heading' => 'Sukurti :label',

            'actions' => [

                'create' => [
                    'label' => 'Sukurti',
                ],

                'create_another' => [
                    'label' => 'Sukurti ir sukurti naują',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Sukurta',
            ],

        ],

    ],

];
