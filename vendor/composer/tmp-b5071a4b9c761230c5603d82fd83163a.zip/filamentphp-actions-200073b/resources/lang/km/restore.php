<?php

return [

    'single' => [

        'label' => 'ស្តារ',

        'modal' => [

            'heading' => 'ស្តារ :label',

            'actions' => [

                'restore' => [
                    'label' => 'ស្តារ',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'បានស្ដារឡើងវិញ',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'បានជ្រើសរើសឡើងវិញ',

        'modal' => [

            'heading' => 'បានជ្រើសរើសឡើងវិញ :label',

            'actions' => [

                'restore' => [
                    'label' => 'ស្តារ',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'បានស្ដារឡើងវិញ',
            ],

        ],

    ],

];
