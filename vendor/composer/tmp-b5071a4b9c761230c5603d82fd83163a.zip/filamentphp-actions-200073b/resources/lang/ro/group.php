<?php

return [

    'trigger' => [
        'label' => 'Operaţii',
    ],

];
