<?php

return [

    'confirmation' => 'Sunteţi sigur că doriţi să efectuaţi operaţia ?',

    'actions' => [

        'cancel' => [
            'label' => 'Anulare',
        ],

        'confirm' => [
            'label' => 'Confirmare',
        ],

        'submit' => [
            'label' => 'Executați',
        ],

    ],

];
