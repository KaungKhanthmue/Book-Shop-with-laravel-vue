<?php

return [

    'single' => [

        'label' => 'Duplicirati',

        'modal' => [

            'heading' => 'Duplicirajte :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Duplicirati',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Zapis dupliciran',
            ],

        ],

    ],

];
