<?php

return [

    'single' => [

        'label' => 'Priložiti',

        'modal' => [

            'heading' => 'Priložite :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Zapis',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Priložite',
                ],

                'attach_another' => [
                    'label' => 'Priložite i priložite još jedan',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Priloženo',
            ],

        ],

    ],

];
