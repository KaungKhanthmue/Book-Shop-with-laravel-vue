<?php

return [

    'single' => [

        'label' => 'Padam',

        'modal' => [

            'heading' => 'Padam :label',

            'actions' => [

                'delete' => [
                    'label' => 'Padam',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Dipadamkan',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Padam pilihan',

        'modal' => [

            'heading' => 'Padam pilihan :label',

            'actions' => [

                'delete' => [
                    'label' => 'Padam pilihan',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Dipadamkan',
            ],

        ],

    ],

];
