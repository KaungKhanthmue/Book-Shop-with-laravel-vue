<?php

return [

    'single' => [

        'label' => 'Dissociar',

        'modal' => [

            'heading' => 'Dissociar :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissociar',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Dissociat',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Dissociar seleccionats',

        'modal' => [

            'heading' => 'Dissociar :label seleccionats',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissociar',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Dissociats',
            ],

        ],

    ],

];
