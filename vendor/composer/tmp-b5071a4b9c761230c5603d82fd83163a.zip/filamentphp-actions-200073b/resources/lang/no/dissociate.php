<?php

return [

    'single' => [

        'label' => 'Dissosiere',

        'modal' => [

            'heading' => 'Dissosiere :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissosier',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Dissosiert',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Dissosiere valgte',

        'modal' => [

            'heading' => 'Dissosiere valgte :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissosier',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Dissosiert',
            ],

        ],

    ],

];
