<?php

return [

    'single' => [

        'label' => 'Gjenskape',

        'modal' => [

            'heading' => 'Gjenskap :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Gjenskap',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Gjenskapt',
            ],

        ],

    ],

];
