<?php

return [

    'single' => [

        'label' => 'Legg til',

        'modal' => [

            'heading' => 'Legg til :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Post',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Legg til',
                ],

                'attach_another' => [
                    'label' => 'Legg til & legg til en annen',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Lagt til',
            ],

        ],

    ],

];
