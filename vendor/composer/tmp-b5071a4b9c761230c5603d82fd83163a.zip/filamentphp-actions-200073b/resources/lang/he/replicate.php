<?php

return [

    'single' => [

        'label' => 'שכפל',

        'modal' => [

            'heading' => 'שכפל את :label',

            'actions' => [

                'replicate' => [
                    'label' => 'שכפל',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'שוכפל',
            ],

        ],

    ],

];
