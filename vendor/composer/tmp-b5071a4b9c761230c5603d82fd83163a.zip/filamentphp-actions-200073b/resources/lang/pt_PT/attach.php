<?php

return [

    'single' => [

        'label' => 'Vincular',

        'modal' => [

            'heading' => 'Vincular :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Registo',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Vincular',
                ],

                'attach_another' => [
                    'label' => 'Vincular e vincular outro',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Vinculado',
            ],

        ],

    ],

];
