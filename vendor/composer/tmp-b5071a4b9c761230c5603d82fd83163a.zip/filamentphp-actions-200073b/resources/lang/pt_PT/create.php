<?php

return [

    'single' => [

        'label' => 'Criar :label',

        'modal' => [

            'heading' => 'Criar :label',

            'actions' => [

                'create' => [
                    'label' => 'Criar',
                ],

                'create_another' => [
                    'label' => 'Criar e criar novo',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Criado',
            ],

        ],

    ],

];
