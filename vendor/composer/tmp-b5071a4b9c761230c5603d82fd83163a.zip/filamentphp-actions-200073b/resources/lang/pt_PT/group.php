<?php

return [

    'trigger' => [
        'label' => 'Acções',
    ],

];
