<?php

return [

    'single' => [

        'label' => 'Associar',

        'modal' => [

            'heading' => 'Associar :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Registo',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Associar',
                ],

                'associate_another' => [
                    'label' => 'Associar e associar outro',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Associado',
            ],

        ],

    ],

];
