<?php

return [

    'single' => [

        'label' => 'Desassociar',

        'modal' => [

            'heading' => 'Desassociar :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Desassociar',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Desassociado',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Desassociar seleccionados',

        'modal' => [

            'heading' => 'Desassociar :label seleccionados',

            'actions' => [

                'dissociate' => [
                    'label' => 'Desassociar',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Desassociado',
            ],

        ],

    ],

];
