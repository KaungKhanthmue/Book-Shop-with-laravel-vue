<?php

return [

    'single' => [

        'label' => 'Əlaqələndir',

        'modal' => [

            'heading' => ':label Əlaqələndir',

            'fields' => [

                'record_id' => [
                    'label' => 'Məlumat',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Əlaqələndir',
                ],

                'associate_another' => [
                    'label' => 'Əlaqələndir və başqasına başla',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Əlaqələndirildi',
            ],

        ],

    ],

];
