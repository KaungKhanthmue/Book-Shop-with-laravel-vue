<?php

return [

    'single' => [

        'label' => 'Dupliceren',

        'modal' => [

            'heading' => ':Label dupliceren',

            'actions' => [

                'replicate' => [
                    'label' => 'Dupliceren',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Gedupliceerd',
            ],

        ],

    ],

];
