<?php

return [

    'single' => [

        'label' => 'တည်းဖြတ်ပါ',

        'modal' => [

            'heading' => ':label ကိုတည်းဖြတ်ပါ',

            'actions' => [

                'save' => [
                    'label' => 'မှတ်ပါ',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'သိမ်းဆည်းပြီး',
            ],

        ],

    ],

];
