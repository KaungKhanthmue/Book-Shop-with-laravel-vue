<?php

return [

    'single' => [

        'label' => '作成',

        'modal' => [

            'heading' => ':label 作成',

            'actions' => [

                'create' => [
                    'label' => '作成',
                ],

                'create_another' => [
                    'label' => '保存して、続けて作成',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => '作成しました',
            ],

        ],

    ],

];
