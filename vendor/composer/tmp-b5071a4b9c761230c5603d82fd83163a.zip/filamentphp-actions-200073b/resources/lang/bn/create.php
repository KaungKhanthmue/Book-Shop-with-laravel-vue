<?php

return [

    'single' => [

        'label' => 'নতুন :label',

        'modal' => [

            'heading' => ':label তৈরী করুন',

            'actions' => [

                'create' => [
                    'label' => 'তৈরী করুন',
                ],

                'create_another' => [
                    'label' => 'তৈরী এবং নতুন তৈরী করুন',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'তৈরী হয়েছে',
            ],

        ],

    ],

];
