<?php

return [

    'single' => [

        'label' => 'नक्कल गर्नुहोस्',

        'modal' => [

            'heading' => ':label को नक्कल गर्नुहोस्',

            'actions' => [

                'replicate' => [
                    'label' => 'नक्कल गर्नुहोस्',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'नक्कल गरियो',
            ],

        ],

    ],

];
