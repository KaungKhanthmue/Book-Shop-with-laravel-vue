<?php

return [

    'single' => [

        'label' => 'हेर्नुहोस्',

        'modal' => [

            'heading' => ':label हेर्नुहोस्',

            'actions' => [

                'close' => [
                    'label' => 'बन्द गर्नुहोस्',
                ],

            ],

        ],

    ],

];
