<?php

return [

    'single' => [

        'label' => 'सम्पादन गर्नुहोस्',

        'modal' => [

            'heading' => ':label सम्पादन गर्नुहोस्',

            'actions' => [

                'save' => [
                    'label' => 'परिवर्तनहरू सुरक्षित गर्नुहोस',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'परिवर्तन सुरक्षित गरियो',
            ],

        ],

    ],

];
