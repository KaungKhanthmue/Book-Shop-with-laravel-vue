<?php

return [

    'single' => [

        'label' => 'संलग्न',

        'modal' => [

            'heading' => ':label सँग संलग्न गर्नुहोस्',

            'fields' => [

                'record_id' => [
                    'label' => 'रेकर्ड',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'संलग्न',
                ],

                'attach_another' => [
                    'label' => 'यो जोड्नुहोस र अर्को जोड्नुहोस',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'संलग्न गरियो',
            ],

        ],

    ],

];
