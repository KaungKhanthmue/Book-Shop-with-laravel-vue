<?php

return [

    'single' => [

        'label' => 'अलग गर्नुहोस्',

        'modal' => [

            'heading' => ':label अलग गर्नुहोस्',

            'actions' => [

                'detach' => [
                    'label' => 'अलग गर्नुहोस्',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'अलग भयो',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'चयन गरिएको अलग गर्नुहोस्',

        'modal' => [

            'heading' => 'चयन गरिएका :label अलग गर्नुहोस्',

            'actions' => [

                'detach' => [
                    'label' => 'अलग गर्नुहोस्',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'अलग भयो',
            ],

        ],

    ],

];
