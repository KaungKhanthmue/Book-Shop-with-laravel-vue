<?php

return [

    'single' => [

        'label' => 'मेटाउनुहोस्',

        'modal' => [

            'heading' => ':label मेटाउनुहोस्',

            'actions' => [

                'delete' => [
                    'label' => 'मेटाउनुहोस्',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'मेटाइयो',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'चयन गरिएको मेटाउनुहोस्',

        'modal' => [

            'heading' => 'चयन गरिएका :label मेटाउनुहोस्',

            'actions' => [

                'delete' => [
                    'label' => 'मेटाउनुहोस्',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'मेटाइयो',
            ],

        ],

    ],

];
