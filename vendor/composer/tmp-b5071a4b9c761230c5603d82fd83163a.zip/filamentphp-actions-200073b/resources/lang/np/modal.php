<?php

return [

    'confirmation' => 'के तपाइँ यो गर्न निश्चित हुनुहुन्छ?',

    'actions' => [

        'cancel' => [
            'label' => 'रद्द गर्नुहोस्',
        ],

        'confirm' => [
            'label' => 'पुष्टि गर्नुहोस्',
        ],

        'submit' => [
            'label' => 'पेश गर्नुहोस्',
        ],

    ],

];
