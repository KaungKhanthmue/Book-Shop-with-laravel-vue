<?php

return [

    'trigger' => [
        'label' => 'کردارەکان',
    ],

];
